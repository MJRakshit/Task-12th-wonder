import { Component, OnInit, Input, ChangeDetectionStrategy} from '@angular/core';
import { Task } from 'src/app/Interface/tasks.interface';

@Component({
  selector: 'app-taskwidget',
  templateUrl: './taskwidget.component.html',
  styleUrls: ['./taskwidget.component.scss'],
   changeDetection: ChangeDetectionStrategy.OnPush
})
export class TaskwidgetComponent implements OnInit {
 @Input() tasks: Task;
  constructor() { }

  ngOnInit() {
  }

  
}
