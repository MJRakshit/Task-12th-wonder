import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskwidgetComponent } from './taskwidget.component';

describe('TaskwidgetComponent', () => {
  let component: TaskwidgetComponent;
  let fixture: ComponentFixture<TaskwidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaskwidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskwidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
