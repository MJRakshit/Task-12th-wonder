import { Component, OnInit } from '@angular/core';
import { Dataservice } from 'src/app/Services/data.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
teamTask: number;
myTask: number;
  constructor(private dataService: Dataservice) { }

  ngOnInit() {
    this.dataService.teamTask.subscribe((x: number)=>{
      this.teamTask = x;
    });
    this.dataService.myTask.subscribe((x: number)=>{
      this.myTask= x;
    })
  }

}
