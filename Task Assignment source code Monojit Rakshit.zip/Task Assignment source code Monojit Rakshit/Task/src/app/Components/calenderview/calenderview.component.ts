import { Component, OnInit } from '@angular/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import { Dataservice } from 'src/app/Services/data.service';
import * as moment from 'moment'
@Component({
  selector: 'app-calenderview',
  templateUrl: './calenderview.component.html',
  styleUrls: ['./calenderview.component.scss']
})
export class CalenderviewComponent implements OnInit {
  calendarPlugins = [dayGridPlugin]; 
  allTask:any;
  eventsArr: any;
  constructor(private dataService:Dataservice) { }

  ngOnInit() {
    this.dataService.allTask.subscribe((data)=>{
      this.allTask = data;
      if(this.allTask.length>0){
        this.eventsArr = [];
        this.createEvent()
      }
      
     })
  }
  createEvent(){
    for(let i = 0; i<this.allTask.length; i++){
      var dateArray = [];
       dateArray = this.createDate(this.allTask[i].start,this.allTask[i].end);
      for(let j = 0; j<dateArray.length; j++){
        var obj = {
           title: this.allTask[i].text,
           date: dateArray[j]
        };
        this.eventsArr.push(obj)
      }
    }
  }
  createDate(start , end){
    var dates = [];
    dates.push(start,end)
    var currDate = moment(start).startOf('day');
    var lastDate = moment(end).startOf('day');
    while(currDate.add(1, 'days').diff(lastDate) < 0) {
        dates.push(moment(currDate.clone().toDate()).format('YYYY-MM-DD'));
    }
   return dates;
  }

}
