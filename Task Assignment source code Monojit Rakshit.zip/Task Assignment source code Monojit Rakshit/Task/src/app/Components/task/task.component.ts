import { Component, OnInit,ChangeDetectionStrategy, ChangeDetectorRef} from '@angular/core';
import { Dataservice } from 'src/app/Services/data.service';
import {MatDialog} from '@angular/material/dialog';
import { AddTaskComponent } from '../add-task/add-task.component';
@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.scss'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class TaskComponent implements OnInit {
  allTask:any;
  filterType: string;
  sortingOption: string;
  constructor(private dataService:Dataservice,public dialog: MatDialog,private cdr: ChangeDetectorRef) { 
    this.filterType="";
    this.sortingOption="";
  }

  ngOnInit() {
    this.dataService.allTask.subscribe((data)=>{
      this.allTask = data;
      this.cdr.detectChanges();
     })
  }
  markTaskAsCompleted(index){
    var obj = [...this.allTask]
    obj[index].isCompleted = true;
    this.dataService.modifyAlltasks(obj);
    this.dataService.snackObserver.next("Task Mark As Done/Complete");
  }
  clearFilter(){
    this.filterType="";
    this.sortingOption="";
  }
  openDialog(): void {
    const dialogRef = this.dialog.open(AddTaskComponent,{
      width: '50%',
      height: '60%',
      disableClose: true 
    });

    dialogRef.afterClosed().subscribe(result => {
     if(result != "close"){
      var obj =  Object.assign([],this.allTask);
       obj.unshift(result)
       this.dataService.modifyAlltasks(obj);
       this.dataService.createNewPersonalTask(result);
       this.dataService.snackObserver.next("Add New Task Successfully")
     }
    });
  }
}
