import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormBuilder, FormGroup, Validators ,} from '@angular/forms';
import * as moment from 'moment'
import { Dataservice } from 'src/app/Services/data.service';
@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.scss']
})
export class AddTaskComponent implements OnInit {
  taskForm: FormGroup;
  constructor(public dialogRef: MatDialogRef<AddTaskComponent>,private formBuilder: FormBuilder,
    private dataservice:Dataservice) {
    this.taskForm = this.formBuilder.group({
      text: ['', Validators.required],
      creator: ['', Validators.required],
      start: ['', Validators.required],
      end: ['', Validators.required],
    });
   }

  ngOnInit() {
  }
  onSubmit(){
    var obj = {text:this.taskForm.controls['text'].value,
              creator:this.taskForm.controls['creator'].value,
              start:moment(this.taskForm.controls['start'].value).format('YYYY-MM-DD'),
              end:moment(this.taskForm.controls['end'].value).format('YYYY-MM-DD'),
              isGlobal: false,
              isLeader: false,
              isCompleted:false,
            };
       //this.dataservice.createNewPersonalTask(obj);
       this.cancelTask(obj);
  }
  cancelTask(res){
    this.dialogRef.close(res);
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.taskForm.controls[controlName].hasError(errorName);
  }
}
