import { Component, OnInit } from '@angular/core';
import { Dataservice } from 'src/app/Services/data.service';
import { Task } from 'src/app/Interface/tasks.interface';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  globalTask:Task;
  personalTask: Task;
  taskByTeamLead:Task
  constructor(private dataService:Dataservice) { }

  ngOnInit() {
     this.dataService.globalTasks.subscribe((data)=>{
      this.globalTask = data;
     })
     this.dataService.personalTasks.subscribe((data)=>{
     this.personalTask = data
     });
     this.dataService.teamLeaderListedTasks.subscribe((data)=>{
      this.taskByTeamLead= data;
     })
  }
  addGlobalTask(){
    var obj = [{
    "text": "Make Test Plan for New Vehicle",
    "isGlobal": true,
    "isLeader": true,
    "creator": "Monojit",
    "isCompleted": false,
    "start": "2019-09-07",
    "end": "2019-09-10",
    }]
    this.dataService.addTask(obj);
  }
}
