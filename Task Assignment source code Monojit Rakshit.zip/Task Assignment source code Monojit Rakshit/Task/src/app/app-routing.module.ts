import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './Components/home/home.component';
import { TaskComponent } from './Components/task/task.component';
import { PagenotfoundComponent } from './Components/pagenotfound/pagenotfound.component';
import { CalenderviewComponent } from './Components/calenderview/calenderview.component';
const routes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full' },
  {path: 'home', component: HomeComponent,pathMatch: 'full'},
  {path: 'task', component: TaskComponent,pathMatch: 'full'},
  {path: 'viewcalender', component:CalenderviewComponent, pathMatch: 'full'},
  {path: 'pagenotfound', component:  PagenotfoundComponent, pathMatch: 'full'},
  { path: '**',  redirectTo: 'pagenotfound', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
