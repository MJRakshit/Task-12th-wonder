import { Pipe, PipeTransform } from '@angular/core';
import { orderBy } from 'lodash';
@Pipe({
  name: 'sortTask'
})
export class SortTaskPipe implements PipeTransform {

  transform(args: any[], sortType: string): any {
    if(sortType == ""){
      return args;
    }else if(sortType == "creator"){
      return orderBy(args, ["creator"], ["asc"]);
    }else if(sortType == "date"){
      return orderBy(args, ["start"], ["asc"]);
    }else{
      return args;
    }
  }

}
