import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'taskFilter'
})
export class TaskFilterPipe implements PipeTransform {

  transform(args: any[],filterType: string): any {
    if(filterType == ""){
      return args;
    }else if(filterType == "leader"){
      return args.filter(task => task.isLeader == true);
    }else if(filterType == "global"){
      return args.filter(task => task.isGlobal == true);
    }else if(filterType == "personal"){
      return args.filter(task => task.isGlobal == false);
    }else{
      return args;
    }
  }
}
