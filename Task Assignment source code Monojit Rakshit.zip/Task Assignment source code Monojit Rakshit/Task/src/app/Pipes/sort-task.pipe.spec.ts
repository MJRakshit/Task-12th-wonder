import { SortTaskPipe } from './sort-task.pipe';

describe('SortTaskPipe', () => {
  it('create an instance', () => {
    const pipe = new SortTaskPipe();
    expect(pipe).toBeTruthy();
  });
});
