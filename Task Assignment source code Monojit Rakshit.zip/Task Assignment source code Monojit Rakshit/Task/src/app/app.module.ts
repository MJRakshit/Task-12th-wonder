import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './Components/home/home.component';
import { TaskComponent } from './Components/task/task.component';
import { PagenotfoundComponent } from './Components/pagenotfound/pagenotfound.component';
import {MatToolbarModule, MatIconModule, MatCardModule, MatSidenavModule, MatListModule, MatButtonModule, MatFormFieldModule, MatInputModule, MatDatepickerModule, MatNativeDateModule} from '@angular/material'
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HeaderComponent } from './Components/header/header.component';
import { Dataservice } from './Services/data.service';
import { HttpClientModule } from '@angular/common/http';
import { TaskwidgetComponent } from './Components/taskwidget/taskwidget.component';
import {MatDividerModule} from '@angular/material/divider';
import { FullCalendarModule } from '@fullcalendar/angular';
import { CalenderviewComponent } from './Components/calenderview/calenderview.component'; // for FullCalendar!
import {MatChipsModule} from '@angular/material/chips';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatSelectModule} from '@angular/material/select';
import { TaskFilterPipe } from './Pipes/task-filter.pipe';
import {MatRadioModule} from '@angular/material/radio';
import { SortTaskPipe } from './Pipes/sort-task.pipe';
import {MatDialogModule} from '@angular/material/dialog';
import { AddTaskComponent } from './Components/add-task/add-task.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TaskComponent,
    PagenotfoundComponent,
    HeaderComponent,
    TaskwidgetComponent,
    CalenderviewComponent,
    TaskFilterPipe,
    SortTaskPipe,
    AddTaskComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule, 
    MatToolbarModule,
    FormsModule, 
    ReactiveFormsModule,
    MatIconModule,
    HttpClientModule,
    MatCardModule,
    MatDividerModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    FullCalendarModule,
    MatButtonModule,
    MatChipsModule,
    MatSnackBarModule,
    MatSelectModule,
    MatRadioModule,
    MatFormFieldModule,
    MatDialogModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule ,
  ],
  providers: [Dataservice,MatDatepickerModule],
  bootstrap: [AppComponent],
  entryComponents:[AddTaskComponent]
})
export class AppModule { }
