import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Dataservice } from './Services/data.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'task';
  action:any
  constructor(private router: Router,private _snackBar: MatSnackBar,
    private dataService: Dataservice){
      this.dataService.snackbarMsg.subscribe((data)=>{
        if(data != ""){
          this.openSnackBar(data)
        }
      });
      this.router.events.subscribe((event: NavigationEnd) => {
        window.scroll(0, 0);
      });
    }
  ngOnInit(){
    this.router.navigate([''])
  }
  openSnackBar(message: string) {
    this._snackBar.open(message, this.action, {
      duration: 2000,
      verticalPosition: "bottom",
      horizontalPosition: "right",
    });
  }
}
