import { HttpClient} from '@angular/common/http'; 
import { Observable, BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';
import { Task } from '../Interface/tasks.interface';
import {map} from 'rxjs/operators'
@Injectable()
export class Dataservice {
   tasks: any;
   x=0;
   private mytasksObserver = new BehaviorSubject<number>(this.x);
   myTask: Observable<number> = this.mytasksObserver.asObservable();
   private teamtasksObserver = new BehaviorSubject<number>(this.x);
   teamTask: Observable<number> = this.teamtasksObserver.asObservable();
   private alltasksObserver = new BehaviorSubject<any>(this.tasks);
   allTask: Observable<Task> = this.alltasksObserver.asObservable();
   private globaltasksObserver = new BehaviorSubject<any>(this.tasks);
   globalTasks: Observable<Task> = this.globaltasksObserver.asObservable();
   private personaltasksObserver = new BehaviorSubject<any>(this.tasks);
   personalTasks: Observable<Task> = this.personaltasksObserver.asObservable();
   private teamLeaderltasksObserver = new BehaviorSubject<any>(this.tasks);
   teamLeaderListedTasks: Observable<Task> = this.teamLeaderltasksObserver.asObservable();
   public snackObserver = new BehaviorSubject<string>("");
   snackbarMsg: Observable<string> = this.snackObserver.asObservable();
   constructor(private http: HttpClient, ) {
        this.getJSON().subscribe(data => {
          this.tasks = data;
          this.getAllGlobalTask();
          this.getAllPersonalTask();
          this.getTeamLeadListedOuttask();
          this.setAlltask(data)
        });
    }
    public getJSON(): Observable<any> {
        return this.http.get("./assets/Datastore/tasks.json")
        .pipe(map((response)=>{
            return response
          }));
    }
    public getAllGlobalTask(){
        var list =  this.tasks.tasks.filter(task => task.isGlobal == true);
        this.globaltasksObserver.next(list);
    }
    public getAllPersonalTask(){
        var list =  this.tasks.tasks.filter(task => task.isGlobal == false);
        this.personaltasksObserver.next(list);
        this.mytasksObserver.next(list.length)
    }
    public getTeamLeadListedOuttask(){
        var list =  this.tasks.tasks.filter(task => task.isLeader == true);
        this.teamLeaderltasksObserver.next(list);
    }
    public setAlltask(data){
        this.alltasksObserver.next(data.tasks);
        this.teamtasksObserver.next(data.tasks.length)
    }
    public modifyAlltasks(data){
        this.alltasksObserver.next(data);
    }
    addTask(tas: any){
        this.globaltasksObserver.next(tas);
    }
    createNewPersonalTask(data){
         var newData=[...this.personaltasksObserver.getValue()];
         newData.unshift(data);
         this.personaltasksObserver.next(newData);
         this.mytasksObserver.next(newData.length);
         this.teamtasksObserver.next(this.alltasksObserver.getValue().length);
    }

    
}